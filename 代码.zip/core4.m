% =========================================================================
% 面向无人机集群的 TF-CPO (地形特征耦合冠豪猪优化) 算法主干
% 核心功能：在 10 维状态空间中寻找最优阵眼，极小化集群能耗极差 \Delta E
% =========================================================================

clear; clc; close all;

%% 1. 加载底层环境与特征
disp('正在加载环境与地形密度矩阵...');
load('Mountain_Env_3km.mat', 'X_final', 'Y_final', 'Z_final', 'Density_Map');
global X_vec Y_vec Z_mat D_map dx dy
X_vec = X_final(1, :); Y_vec = Y_final(:, 1);
Z_mat = Z_final; D_map = Density_Map;
dx = X_vec(2) - X_vec(1); dy = Y_vec(2) - Y_vec(1);

%% 2. TF-CPO 算法参数设置
Dim = 10;                  % 10维状态空间 (5架无人机的 X, Y 坐标索引)
PopSize = 15;              % 种群规模 (为保证演示速度适中，设为15)
MaxIter = 30;              % 最大迭代次数
num_uavs = 5;

% 搜索边界 (分别严格限制 X 和 Y 轴在地图索引范围内，预留 5% 边界防越界)
lb = zeros(1, Dim);
ub = zeros(1, Dim);
% 状态空间中奇数位为 X 坐标，偶数位为 Y 坐标
lb(1:2:end) = round(length(X_vec) * 0.05);
lb(2:2:end) = round(length(Y_vec) * 0.05);
ub(1:2:end) = round(length(X_vec) * 0.95);
ub(2:2:end) = round(length(Y_vec) * 0.95);

%% 3. 基于 Tent 混沌映射的种群初始化
disp('======================================================');
disp('TF-CPO 算法启动：正在通过 Tent 混沌映射初始化种群...');
Pop = zeros(PopSize, Dim);
% 混沌序列生成
x_tent = rand(1, Dim);
for i = 1:PopSize
    for j = 1:Dim
        if x_tent(j) < 0.5
            x_tent(j) = 2 * x_tent(j);
        else
            x_tent(j) = 2 * (1 - x_tent(j));
        end
    end
    Pop(i, :) = round(lb + x_tent .* (ub - lb));
end

Fitness = zeros(PopSize, 1);
h_wait = waitbar(0, '初始化种群适应度计算中...');

% 初始适应度计算
for i = 1:PopSize
    Fitness(i) = Evaluate_Fitness(Pop(i, :));
    waitbar(i/PopSize, h_wait, sprintf('计算初始种群: %d/%d', i, PopSize));
end

[BestFit, BestIdx] = min(Fitness);
BestPosition = Pop(BestIdx, :);
Convergence_Curve = zeros(1, MaxIter);

%% 4. TF-CPO 主循环
disp('开始地形特征耦合的全局寻优...');
for iter = 1:MaxIter
    % 更新进度条
    waitbar(iter/MaxIter, h_wait, sprintf('TF-CPO 优化迭代中... %d/%d (当前极差: %.2f kJ)', iter, MaxIter, BestFit));
    
    for i = 1:PopSize
        % 提取当前个体的 5 个阵眼坐标
        curr_pos = Pop(i, :);
        new_pos = curr_pos;
        
        % 获取当前个体中 5 个阵眼所在位置的地形密度均值 (核心地形耦合)
        idx_x = curr_pos(1:2:end);
        idx_y = curr_pos(2:2:end);
        
        % 边界保护
        idx_x = max(min(idx_x, ub(1)), lb(1));
        idx_y = max(min(idx_y, ub(2)), lb(2));
        
        mean_density = 0;
        for k = 1:num_uavs
            mean_density = mean_density + D_map(idx_y(k), idx_x(k));
        end
        mean_density = mean_density / num_uavs;
        
        % TF 机制：地形密度越大，搜索步长衰减越快 (防止跳出险峻峡谷中的极值点)
        TF_Alpha = 1 - (iter / MaxIter)^(1 / (mean_density + 0.1));
        
        % CPO 核心扰动公式 (简化与改良版)
        r1 = randi([1, PopSize]);
        r2 = randi([1, PopSize]);
        
        if rand < 0.5
            % 探索阶段 (全局搜索)
            new_pos = curr_pos + round(TF_Alpha * rand(1, Dim) .* (Pop(r1, :) - Pop(r2, :)));
        else
            % 开发阶段 (局部利用)
            new_pos = BestPosition + round(TF_Alpha * randn(1, Dim));
        end
        
        % 边界约束处理
        new_pos = max(min(round(new_pos), ub), lb);
        
        % 评估新位置
        new_fit = Evaluate_Fitness(new_pos);
        
        % 贪婪更新
        if new_fit < Fitness(i)
            Pop(i, :) = new_pos;
            Fitness(i) = new_fit;
            if new_fit < BestFit
                BestFit = new_fit;
                BestPosition = new_pos;
                fprintf('迭代 %d: 发现更优解，能耗极差降至 %.2f kJ\n', iter, BestFit);
            end
        end
    end
    Convergence_Curve(iter) = BestFit;
end

close(h_wait);
disp('TF-CPO 优化完成！');
disp('======================================================');

%% 5. 绘制收敛曲线
figure('Name', 'TF-CPO Convergence Curve', 'Position', [300, 300, 700, 500], 'Color', 'white');
plot(1:MaxIter, Convergence_Curve, '-o', 'LineWidth', 2.5, 'MarkerSize', 6, 'MarkerFaceColor', 'r');
title('TF-CPO Algorithm Convergence Curve', 'FontSize', 14);
xlabel('Iteration', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Fitness Value (\Delta E in kJ)', 'FontSize', 12, 'FontWeight', 'bold');
grid on;
set(gca, 'FontSize', 11);
text(MaxIter*0.6, BestFit + (max(Convergence_Curve)-BestFit)*0.2, ...
    sprintf('最优能耗极差: %.2f kJ', BestFit), 'FontSize', 12, 'FontWeight', 'bold', 'BackgroundColor', 'w');

% 保存最优阵眼供后续验证调用
Optimal_Seeds = BestPosition;
save('TF_CPO_Optimal_Seeds.mat', 'Optimal_Seeds', 'Convergence_Curve');
disp('最优解已保存至 TF_CPO_Optimal_Seeds.mat');

%% ========================================================================
% 局部函数区：适应度快速评估模块 (TW-CVT + 简易能耗积分)
% ========================================================================
function fitness = Evaluate_Fitness(solution)
    global X_vec Y_vec Z_mat D_map dx dy
    
    num_uavs = 5;
    seeds_x = solution(1:2:end)';
    seeds_y = solution(2:2:end)';
    
    [num_rows, num_cols] = size(D_map);
    
    % --- 步骤 A: 快速 TW-CVT (Lloyd 算法, 为保证速度仅迭代 15 次) ---
    [Grid_X, Grid_Y] = meshgrid(1:num_cols, 1:num_rows);
    grid_points = [Grid_X(:), Grid_Y(:)];
    
    for iter_cvt = 1:15
        distances = pdist2(grid_points, [seeds_x, seeds_y]);
        [~, min_idx] = min(distances, [], 2);
        partition_map = reshape(min_idx, num_rows, num_cols);
        
        for k = 1:num_uavs
            mask = (partition_map == k);
            if sum(mask(:)) == 0, continue; end
            region_density = D_map(mask);
            seeds_x(k) = sum(Grid_X(mask) .* region_density) / sum(region_density);
            seeds_y(k) = sum(Grid_Y(mask) .* region_density) / sum(region_density);
        end
    end
    
    % --- 步骤 B: 快速能耗估算模型 ---
    % 为加速搜索，不再生成完整 Boustrophedon 航线，而是基于泰森区域的地形起伏进行积分近似
    E_k = zeros(num_uavs, 1);
    P_level = 270; % 水平功耗
    k_2 = 45;      % 爬升功耗系数
    v_cruise = 8;
    footprint = 50;
    
    for k = 1:num_uavs
        mask = (partition_map == k);
        if sum(mask(:)) == 0, E_k(k) = 999999; continue; end % 极度惩罚空区域
        
        % 提取该区域内所有栅格的高程，计算 X 和 Y 方向的绝对高差(近似爬升量)
        Z_region = Z_mat .* mask;
        [dzdx, dzdy] = gradient(Z_region, dx, dy);
        
        % 近似俯仰角正弦值
        sin_theta = sqrt(dzdx.^2 + dzdy.^2) ./ sqrt(dx^2 + dzdx.^2 + dzdy.^2);
        
        % 计算每个栅格的飞行时间 (假设航线铺满该栅格需要的距离 = dx * dy / footprint)
        dist_in_cell = (dx * dy) / footprint;
        dt = dist_in_cell / v_cruise;
        
        % 计算该区域总能耗积分
        Power_mat = P_level + k_2 * max(0, v_cruise * sin_theta);
        E_k(k) = sum(Power_mat(mask) .* dt);
    end
    
    % 返回能耗极差 \Delta E (单位: kJ)
    fitness = (max(E_k) - min(E_k)) / 1000;
end