% =========================================================================
% 面向无人机集群的山地专属非线性动力学能耗评估模块
% 核心功能：计算 5 架无人机执行 3D 仿地航线时的真实能耗，暴露出负载不均问题
% =========================================================================

clear; clc; close all;

%% 1. 加载 3D 轨迹数据
disp('正在加载 3D 仿地航线数据...');
load('Final_3D_Trajectories.mat', 'UAV_Paths_3D');
num_uavs = length(UAV_Paths_3D);

%% 2. 山地专属非线性能耗模型参数 (严格参考 Drones/TRO 期刊常见设定)
% 基础参数
v_cruise = 8.0;               % 巡航速度 (m/s)
P_hover = 120;                % 悬停基础功耗 P_0 (W)
P_aero = 150;                 % 平飞气动附加功耗 k_1*v^2 (W)
P_level = P_hover + P_aero;   % 水平飞行总功耗 (270 W)

% 爬升惩罚参数
% 对应公式: P(v, \theta) = P_level + k_2 * max(0, v * sin(\theta))
k_2 = 45;                     % 爬升额外功耗系数

%% 3. 计算每架无人机的总能耗
disp('======================================================');
disp('开始计算各无人机山地飞行真实能耗...');

Total_Energy_Joules = zeros(num_uavs, 1);
Total_Distance_m = zeros(num_uavs, 1);
Total_Time_s = zeros(num_uavs, 1);

for k = 1:num_uavs
    traj = UAV_Paths_3D{k};
    if isempty(traj)
        continue;
    end
    
    E_k = 0; % 第 k 架无人机的累计能耗
    dist_k = 0;
    
    % 遍历轨迹中的每一段线段
    for i = 1:(size(traj, 1) - 1)
        p1 = traj(i, :);
        p2 = traj(i+1, :);
        
        % 计算三维空间欧氏距离
        segment_dist = norm(p2 - p1);
        if segment_dist == 0
            continue;
        end
        dist_k = dist_k + segment_dist;
        
        % 计算高程差与俯仰角 \theta
        dz = p2(3) - p1(3);
        theta = asin(dz / segment_dist); % 俯仰角 (弧度)
        
        % 飞行时间
        dt = segment_dist / v_cruise;
        
        % 核心能耗公式：爬升增加功耗，俯冲不减少功耗 (下坡也需要抗风维持姿态)
        % \max(0, v \sin\theta) 保证了只有 dz > 0 时才施加惩罚
        P_current = P_level + k_2 * max(0, v_cruise * sin(theta));
        
        % 累计该段能耗 (焦耳)
        E_k = E_k + P_current * dt;
    end
    
    Total_Energy_Joules(k) = E_k;
    Total_Distance_m(k) = dist_k;
    Total_Time_s(k) = dist_k / v_cruise;
    
    fprintf('UAV %d: 飞行距离 %.2f m, 耗时 %.1f min, 总能耗 %.2f kJ\n', ...
        k, dist_k, Total_Time_s(k)/60, E_k/1000);
end

%% 4. 计算负载均衡度 (适应度函数核心指标)
% 将能耗转换为千焦 (kJ) 方便图表展示
Energy_kJ = Total_Energy_Joules / 1000;
Max_Energy = max(Energy_kJ);
Min_Energy = min(Energy_kJ);
Energy_Difference = Max_Energy - Min_Energy;

fprintf('\n【集群负载极差 (Max - Min)】: %.2f kJ\n', Energy_Difference);
disp('======================================================');

%% 5. 绘制能耗不均柱状图
figure('Name', 'UAV Energy Consumption Analysis', 'Position', [200, 200, 700, 500], 'Color', 'white');

b = bar(1:num_uavs, Energy_kJ, 'FaceColor', 'flat');
% 为每个柱子分配不同颜色以对应 3D 轨迹图
colors = lines(num_uavs);
b.CData = colors;

hold on;
% 绘制最高与最低能耗参考线
yline(Max_Energy, 'r--', 'LineWidth', 1.5, 'Label', 'Max Energy', 'LabelHorizontalAlignment', 'left');
yline(Min_Energy, 'g--', 'LineWidth', 1.5, 'Label', 'Min Energy', 'LabelHorizontalAlignment', 'left');

% 标注能耗极差 \Delta E
mid_x = (num_uavs + 1) / 2;
plot([mid_x, mid_x], [Min_Energy, Max_Energy], 'k-|', 'LineWidth', 1.5);
text(mid_x + 0.1, (Max_Energy + Min_Energy)/2, sprintf('\\Delta E = %.2f kJ', Energy_Difference), ...
    'FontSize', 12, 'FontWeight', 'bold', 'BackgroundColor', 'w');

title('Energy Consumption of Initial Random Partitioning', 'FontSize', 14);
xlabel('UAV Index', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Total Energy (kJ)', 'FontSize', 12, 'FontWeight', 'bold');
set(gca, 'XTick', 1:num_uavs, 'XTickLabel', {'UAV 1', 'UAV 2', 'UAV 3', 'UAV 4', 'UAV 5'}, 'FontSize', 11);
grid on; hold off;