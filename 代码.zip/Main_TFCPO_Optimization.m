% =========================================================================
% 面向无人机集群的 TF-CPO (地形特征耦合冠豪猪优化) 算法主程序最终版
% 核心创新 1：基于大容量混沌候选池的精英初始化策略 (Elite Chaotic Pool)
% 核心创新 2：直接能量驱动 Voronoi 划分 (去除Lloyd劫持，释放连续空间潜能)
% 核心创新 3：Min-Max 瓶颈能耗优化架构 (彻底解决木桶效应与短板单机坠机风险)
% =========================================================================

clear; clc; close all;

%% 1. 加载底层环境与特征
disp('正在加载环境与地形密度矩阵...');
load('Mountain_Env_3km.mat', 'X_final', 'Y_final', 'Z_final', 'Density_Map');
global X_vec Y_vec Z_mat D_map dx dy
X_vec = X_final(1, :); Y_vec = Y_final(:, 1);
Z_mat = Z_final; D_map = Density_Map;
dx = X_vec(2) - X_vec(1); dy = Y_vec(2) - Y_vec(1);

%% 2. TF-CPO 算法参数设置与边界初始化
Dim = 10;                  % 10维状态空间 (5架无人机的 X, Y 坐标索引)
PoolSize = 100;            % 大容量候选池规模 
PopSize = 15;              % 实际进入迭代的种群规模 (取前15名精英)
MaxIter = 40;              % 最大迭代次数 (对齐对比实验的40代)
num_uavs = 5;

% 搜索边界 (分别严格限制 X 和 Y 轴在地图索引范围内，预留 5% 边界防越界)
lb = zeros(1, Dim);
ub = zeros(1, Dim);
lb(1:2:end) = round(length(X_vec) * 0.05); % X轴下界
lb(2:2:end) = round(length(Y_vec) * 0.05); % Y轴下界
ub(1:2:end) = round(length(X_vec) * 0.95); % X轴上界
ub(2:2:end) = round(length(Y_vec) * 0.95); % Y轴上界

%% 3. 基于 Tent 混沌映射的精英候选池初始化 (Elite Pool Initialization)
disp('======================================================');
disp('阶段 1：正在生成大容量 Tent 混沌候选池并进行精英筛选...');
Pool = zeros(PoolSize, Dim);
x_tent = rand(1, Dim);

% 生成 100 个混沌候选解
for i = 1:PoolSize
    for j = 1:Dim
        if x_tent(j) < 0.5
            x_tent(j) = 2 * x_tent(j);
        else
            x_tent(j) = 2 * (1 - x_tent(j));
        end
    end
    Pool(i, :) = round(lb + x_tent .* (ub - lb));
end

PoolFitness = zeros(PoolSize, 1);
h_wait = waitbar(0, '混沌候选池适应度评估中...');

% 评估 100 个个体的适应度
for i = 1:PoolSize
    PoolFitness(i) = Evaluate_Fitness(Pool(i, :));
    if mod(i, 5) == 0 || i == 1
        waitbar(i/PoolSize, h_wait, sprintf('筛选精英基因中: %d/%d', i, PoolSize));
    end
end

% 排序并选出最优秀的 PopSize (15) 个个体构成初代种群
[sortedFit, sortIdx] = sort(PoolFitness);
Pop = Pool(sortIdx(1:PopSize), :);
Fitness = sortedFit(1:PopSize);

BestFit = Fitness(1);
BestPosition = Pop(1, :);
Convergence_Curve = zeros(1, MaxIter);

fprintf('精英筛选完成！初始最优瓶颈能耗锁定为: %.2f kJ\n', BestFit);
disp('======================================================');

%% 4. TF-CPO 主循环
disp('阶段 2：开始地形特征耦合的全局寻优迭代...');
for iter = 1:MaxIter
    waitbar(iter/MaxIter, h_wait, sprintf('TF-CPO 优化迭代中... %d/%d (当前瓶颈: %.2f kJ)', iter, MaxIter, BestFit));
    
    for i = 1:PopSize
        curr_pos = Pop(i, :);
        new_pos = curr_pos;
        
        % 获取当前个体中 5 个阵眼所在位置的地形密度均值 (核心地形耦合)
        idx_x = curr_pos(1:2:end);
        idx_y = curr_pos(2:2:end);
        idx_x = max(min(idx_x, ub(1:2:end)), lb(1:2:end));
        idx_y = max(min(idx_y, ub(2:2:end)), lb(2:2:end));
        
        mean_density = 0;
        for k = 1:num_uavs
            mean_density = mean_density + D_map(idx_y(k), idx_x(k));
        end
        mean_density = mean_density / num_uavs;
        
        % TF 机制：地形密度越大，搜索步长衰减越快
        TF_Alpha = 1 - (iter / MaxIter)^(1 / (mean_density + 0.1));
        
        % CPO 扰动公式
        r1 = randi([1, PopSize]); r2 = randi([1, PopSize]);
        if rand < 0.5
            new_pos = curr_pos + round(TF_Alpha * rand(1, Dim) .* (Pop(r1, :) - Pop(r2, :)));
        else
            new_pos = BestPosition + round(TF_Alpha * randn(1, Dim));
        end
        
        % 边界约束处理
        new_pos = max(min(round(new_pos), ub), lb);
        
        % 评估并贪婪更新
        new_fit = Evaluate_Fitness(new_pos);
        if new_fit < Fitness(i)
            Pop(i, :) = new_pos;
            Fitness(i) = new_fit;
            if new_fit < BestFit
                BestFit = new_fit;
                BestPosition = new_pos;
                fprintf('迭代 %d: 发现更优解，瓶颈能耗降至 %.2f kJ\n', iter, BestFit);
            end
        end
    end
    Convergence_Curve(iter) = BestFit;
end

close(h_wait);
disp('TF-CPO 全局优化完成！');
disp('======================================================');

%% 5. 绘制收敛曲线并保存最优解
figure('Name', 'TF-CPO Convergence Curve', 'Position', [300, 300, 700, 500], 'Color', 'white');
plot(1:MaxIter, Convergence_Curve, '-o', 'LineWidth', 2.5, 'MarkerSize', 6, 'MarkerFaceColor', 'r');
title('Elite TF-CPO Algorithm Convergence Curve', 'FontSize', 14);
xlabel('Iteration', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Bottleneck Drone Energy (Max E in kJ)', 'FontSize', 12, 'FontWeight', 'bold'); % 更新为新指标标签
grid on; set(gca, 'FontSize', 11);

% 在曲线上动态标注最优值
text(MaxIter*0.5, BestFit + (max(Convergence_Curve)-BestFit)*0.15, ...
    sprintf('最优瓶颈能耗: %.2f kJ', BestFit), 'FontSize', 12, 'FontWeight', 'bold', 'BackgroundColor', 'w');

Optimal_Seeds = BestPosition;
save('TF_CPO_Optimal_Seeds.mat', 'Optimal_Seeds', 'Convergence_Curve');
disp('最优解已保存至 TF_CPO_Optimal_Seeds.mat');

%% ========================================================================
% 局部函数区：【核心重构】直接能量驱动 Voronoi 与 Min-Max 评估模块
% ========================================================================
function fitness = Evaluate_Fitness(solution)
    global X_vec Y_vec Z_mat D_map dx dy
    num_uavs = 5;
    seeds_x = solution(1:2:end)'; seeds_y = solution(2:2:end)';
    [num_rows, num_cols] = size(D_map);
    
    % 步骤 A: 直接 Voronoi 空间划分 (彻底删除 Lloyd 迭代劫持)
    [Grid_X, Grid_Y] = meshgrid(1:num_cols, 1:num_rows);
    grid_points = [Grid_X(:), Grid_Y(:)];
    
    distances = pdist2(grid_points, [seeds_x, seeds_y]);
    [~, min_idx] = min(distances, [], 2);
    partition_map = reshape(min_idx, num_rows, num_cols);
    
    % 步骤 B: 基于真实高程积分的快速能耗估算
    E_k = zeros(num_uavs, 1);
    P_level = 270; k_2 = 45; v_cruise = 8; footprint = 50;
    
    for k = 1:num_uavs
        mask = (partition_map == k);
        if sum(mask(:)) == 0, E_k(k) = 999999; continue; end % 极度惩罚空区域
        
        Z_region = Z_mat .* mask;
        [dzdx, dzdy] = gradient(Z_region, dx, dy);
        sin_theta = sqrt(dzdx.^2 + dzdy.^2) ./ sqrt(dx^2 + dzdx.^2 + dzdy.^2);
        
        dist_in_cell = (dx * dy) / footprint;
        dt = dist_in_cell / v_cruise;
        
        Power_mat = P_level + k_2 * max(0, v_cruise * sin_theta);
        E_k(k) = sum(Power_mat(mask) .* dt);
    end
    
    % 步骤 C: 【学术升华】极小化最大单机能耗 (Max E) + 极微弱的总能耗惩罚(防畸形)
    fitness = max(E_k) / 1000 + 0.05 * (sum(E_k)/1000/num_uavs); 
end