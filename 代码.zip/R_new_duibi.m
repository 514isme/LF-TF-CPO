% =========================================================================
% 面向顶级期刊的 50次蒙特卡洛独立重复实验统计 (Monte Carlo Validation)
% 目的：获取合法、严谨的 Mean ± Std，以回应审稿人对随机性波动的质疑
% 修复：关闭 parfor 并行池，采用最稳定的单核顺序执行，规避中文路径编码崩溃
% =========================================================================
clear; clc; close all;

%% 1. 加载底层环境与特征
disp('正在加载环境与地形矩阵...');
load('Mountain_Env_3km.mat', 'X_final', 'Y_final', 'Z_final', 'Density_Map');
global X_vec Y_vec Z_mat D_map dx dy num_uavs
X_vec = X_final(1, :); Y_vec = Y_final(:, 1);
Z_mat = Z_final; D_map = Density_Map;
dx = X_vec(2) - X_vec(1); dy = Y_vec(2) - Y_vec(1);
num_uavs = 5;

%% 2. 实验全局参数
Dim = 10; PopSize = 15; MaxIter = 80;
lb = zeros(1, Dim); ub = zeros(1, Dim);
lb(1:2:end) = round(length(X_vec) * 0.05); lb(2:2:end) = round(length(Y_vec) * 0.05);
ub(1:2:end) = round(length(X_vec) * 0.95); ub(2:2:end) = round(length(Y_vec) * 0.95);
beta_levy = 1.5;
sigma_u = (gamma(1+beta_levy)*sin(pi*beta_levy/2)/(gamma((1+beta_levy)/2)*beta_levy*2^((beta_levy-1)/2)))^(1/beta_levy);

%% 3. 蒙特卡洛循环设置
Num_Runs = 50; % 审稿人要求的 50 次重复
disp(['======================================================']);
disp(['开始执行 ', num2str(Num_Runs), ' 次蒙特卡洛独立重复实验 (预计耗时 7-8 分钟)...']);

% 记录 LF-TF-CPO 在 50 次运行中的高保真指标
MC_MaxE = zeros(1, Num_Runs);
MC_TotE = zeros(1, Num_Runs);
MC_StdE = zeros(1, Num_Runs);
MC_Turns = zeros(1, Num_Runs);
MC_Path = zeros(1, Num_Runs);

% 取消全局随机种子锁定，让每次运行的随机熵都不同！
rng('shuffle'); 

% 核心修复：将 parfor 改为普通的 for，彻底规避系统环境的中文字符编码崩溃
for run_idx = 1:Num_Runs
    fprintf('正在运行第 %d / %d 次模拟...\n', run_idx, Num_Runs);
    
    % 初始化算法 
    PoolSize = 100; Pool = zeros(PoolSize, Dim); x_tent = rand(1, Dim);
    for i = 1:PoolSize
        for j = 1:Dim
            if x_tent(j) < 0.5, x_tent(j) = 2*x_tent(j); else, x_tent(j) = 2*(1-x_tent(j)); end
        end
        Pool(i, :) = lb + x_tent .* (ub - lb);
    end
    PoolFit = zeros(PoolSize, 1);
    for i = 1:PoolSize, [PoolFit(i), ~] = Evaluate_Fitness(Pool(i, :)); end
    [sortFit, sortIdx] = sort(PoolFit); Pop_TFCPO = Pool(sortIdx(1:PopSize), :); Fit_TFCPO = sortFit(1:PopSize);
    BestFit_TFCPO = Fit_TFCPO(1); BestPos_TFCPO = Pop_TFCPO(1, :);
    
    for iter = 1:MaxIter
        for i = 1:PopSize
            curr_pos = Pop_TFCPO(i, :);
            idx_x = round(max(min(curr_pos(1:2:end), ub(1:2:end)), lb(1:2:end)));
            idx_y = round(max(min(curr_pos(2:2:end), ub(2:2:end)), lb(2:2:end)));
            mean_d = sum(D_map(sub2ind(size(D_map), idx_y, idx_x))) / num_uavs;
            TF_Alpha = (1 - iter/MaxIter)^(0.8 / (mean_d + 0.1)); 
            
            r1 = randi([1, PopSize]); r2 = randi([1, PopSize]);
            if rand < 0.5, new_pos = curr_pos + TF_Alpha * rand(1, Dim) .* (Pop_TFCPO(r1, :) - Pop_TFCPO(r2, :));
            else, new_pos = BestPos_TFCPO + TF_Alpha * randn(1, Dim) * 5; end
            new_pos = max(min(new_pos, ub), lb); 
            
            [new_fit, ~] = Evaluate_Fitness(new_pos);
            if new_fit < Fit_TFCPO(i)
                Pop_TFCPO(i, :) = new_pos; Fit_TFCPO(i) = new_fit;
                if new_fit < BestFit_TFCPO, BestFit_TFCPO = new_fit; BestPos_TFCPO = new_pos; end
            end
        end
        u = randn(1, Dim) * sigma_u; v = randn(1, Dim); step_levy = u ./ abs(v).^(1/beta_levy);
        mutated_best = BestPos_TFCPO + TF_Alpha .* step_levy * 2; 
        mutated_best = max(min(mutated_best, ub), lb);
        [mutated_fit, ~] = Evaluate_Fitness(mutated_best);
        if mutated_fit < BestFit_TFCPO
            BestFit_TFCPO = mutated_fit; BestPos_TFCPO = mutated_best;
            [~, worst_idx] = max(Fit_TFCPO); Pop_TFCPO(worst_idx, :) = BestPos_TFCPO; Fit_TFCPO(worst_idx) = BestFit_TFCPO;
        end
    end
    
    % 进行高保真考核
    sol = BestPos_TFCPO; seeds_x = round(sol(1:2:end))'; seeds_y = round(sol(2:2:end))';
    [Grid_X, Grid_Y] = meshgrid(1:size(D_map,2), 1:size(D_map,1)); distances = pdist2([Grid_X(:), Grid_Y(:)], [seeds_x, seeds_y]);
    [~, min_idx] = min(distances, [], 2); part_map = reshape(min_idx, size(D_map,1), size(D_map,2));
    
    [max_eng, tot_len, tot_eng, eng_std, turns, ~] = Evaluate_HighFidelity_Metrics(part_map, Z_mat, X_vec, Y_vec, dx, dy);
    
    MC_MaxE(run_idx) = max_eng / 1000;
    MC_TotE(run_idx) = tot_eng / 1000;
    MC_StdE(run_idx) = eng_std / 1000;
    MC_Turns(run_idx) = turns;
    MC_Path(run_idx) = tot_len / 1000;
end

disp('50次蒙特卡洛统计完毕！正在生成学术报告...');

%% 4. 统计分析与打印输出
fprintf('\n================== Proposed LF-TF-CPO: 50 Runs Statistical Results ==================\n');
fprintf('Max_E (kJ)   : %.2f ± %.2f (最佳: %.2f)\n', mean(MC_MaxE), std(MC_MaxE), min(MC_MaxE));
fprintf('Total_E (kJ) : %.2f ± %.2f\n', mean(MC_TotE), std(MC_TotE));
fprintf('E_Std (kJ)   : %.2f ± %.2f\n', mean(MC_StdE), std(MC_StdE));
fprintf('Turns        : %.0f ± %.0f\n', mean(MC_Turns), std(MC_Turns));
fprintf('Path (km)    : %.2f ± %.2f\n', mean(MC_Path), std(MC_Path));
fprintf('====================================================================================\n');
fprintf('>>> 导师提示：你可以将这组带有 ± 标准差的合法数据，直接填入 Table 2 中！\n');

%% ================= 底层评估函数 =================
function [fitness, pure_max_e] = Evaluate_Fitness(sol)
    global Z_mat D_map dx dy num_uavs
    sx = round(sol(1:2:end))'; sy = round(sol(2:2:end))'; 
    [nr, nc] = size(D_map); [GX, GY] = meshgrid(1:nc, 1:nr); ds = pdist2([GX(:), GY(:)], [sx, sy]);
    [~, mi] = min(ds, [], 2); pm = reshape(mi, nr, nc);
    Ek = zeros(num_uavs,1); PL = 270; k2 = 45; vc = 8; fp = 50;
    for k = 1:num_uavs
        mk = (pm == k); if ~any(mk(:)), Ek(k) = 1e6; continue; end
        Zr = Z_mat .* mk; [dzx, dzy] = gradient(Zr, dx, dy);
        st = sqrt(dzx.^2 + dzy.^2) ./ sqrt(dx^2 + dzx.^2 + dzy.^2);
        Ek(k) = sum((PL + k2 * max(0, vc * st(:))) * (dx*dy/fp/vc));
    end
    pure_max_e = max(Ek) / 1000; fitness = pure_max_e + 0.05 * (std(Ek)/1000); 
end

function [max_eng, tl, te, es, tr, mt] = Evaluate_HighFidelity_Metrics(part_map, Z_mat, X_vec, Y_vec, dx, dy)
    global num_uavs
    fp = 50; vc = 8; PL = 270; k_2 = 45; sweep_step = max(1, round(fp / dy)); 
    Lk = zeros(num_uavs, 1); Ek = zeros(num_uavs, 1); Tk = zeros(num_uavs, 1); Trk = zeros(num_uavs, 1);
    for k = 1:num_uavs
        mk = (part_map == k); vy = find(any(mk, 2)); if isempty(vy), continue; end
        px = []; py = []; d = 1; tc = 0;
        for r = min(vy) : sweep_step : max(vy)
            vx = find(mk(r, :)); if isempty(vx), continue; end
            if d == 1, px = [px, min(vx), max(vx)]; else, px = [px, max(vx), min(vx)]; end
            py = [py, r, r]; d = -d; tc = tc + 1;
        end
        if isempty(px), continue; end
        phys_x = interp1(1:length(X_vec), X_vec, px); phys_y = interp1(1:length(Y_vec), Y_vec, py);
        phys_z = zeros(size(phys_x)); for i = 1:length(phys_x), phys_z(i) = Z_mat(round(py(i)), round(px(i))) + 50; end
        traj = [phys_x', phys_y', phys_z']; dist_k = 0; eng_k = 0;
        for i = 1:(size(traj, 1) - 1)
            seg_dist = norm(traj(i+1, :) - traj(i, :)); if seg_dist == 0, continue; end
            dist_k = dist_k + seg_dist; theta = asin((traj(i+1,3) - traj(i,3)) / seg_dist);
            eng_k = eng_k + (PL + k_2 * max(0, vc * sin(theta))) * (seg_dist / vc);
        end
        Lk(k) = dist_k; Ek(k) = eng_k; Tk(k) = dist_k / vc; Trk(k) = tc * 2; 
    end
    max_eng = max(Ek); tl = sum(Lk); te = sum(Ek); es = std(Ek); tr = sum(Trk); mt = max(Tk);
end