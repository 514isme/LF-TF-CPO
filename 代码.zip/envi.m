% =========================================================================
% 面向无人机集群的高复杂地形自动截取与物理特征重构代码
% 核心功能：截取 3km x 3km 核心区，并提取坡度、粗糙度与 TW-CVT 密度地图
% =========================================================================

clear; clc; close all;

%% 1. 读取真实 GeoTIFF 高程数据
filename = 'ASTGTMV003_N25E099_dem.tif'; % 确保此文件在当前目录下

[Z_raw, R] = readgeoraster(filename);
Z_raw = double(Z_raw);

% 剔除无效的 NoData 值，重置为 0
invalid_value_threshold = -100; 
Z_raw(Z_raw < invalid_value_threshold) = 0; 

%% 2. 提取全图物理边界并构建网格
[num_rows, num_cols] = size(Z_raw);

if isprop(R, 'XWorldLimits')
    x_lim = R.XWorldLimits; y_lim = R.YWorldLimits;
elseif isprop(R, 'LongitudeLimits')
    x_lim = R.LongitudeLimits; y_lim = R.LatitudeLimits;
else
    error('未知的空间参考类型');
end

if max(abs(x_lim)) <= 180
    mean_lat = mean(y_lim); 
    x_meters_raw = linspace(0, (x_lim(2)-x_lim(1)) * 111000 * cosd(mean_lat), num_cols);
    y_meters_raw = linspace(0, (y_lim(2)-y_lim(1)) * 111000, num_rows);
else
    x_meters_raw = linspace(0, x_lim(2)-x_lim(1), num_cols);
    y_meters_raw = linspace(0, y_lim(2)-y_lim(1), num_rows);
end

[X_full, Y_full] = meshgrid(x_meters_raw, y_meters_raw);

%% 3. 核心实验区域自动寻优截取 (Sliding Window Search)
target_size_m = 3000; 
dx = abs(x_meters_raw(2) - x_meters_raw(1));
dy = abs(y_meters_raw(2) - y_meters_raw(1));
win_cols = min(round(target_size_m / dx), num_cols);
win_rows = min(round(target_size_m / dy), num_rows);

disp('正在全图中搜索地形起伏最剧烈的核心测绘区域，请稍候...');
max_var = -1; best_r = 1; best_c = 1;
step_r = max(1, round(win_rows / 5));
step_c = max(1, round(win_cols / 5));

for r = 1 : step_r : (num_rows - win_rows + 1)
    for c = 1 : step_c : (num_cols - win_cols + 1)
        sub_Z = Z_raw(r : r+win_rows-1, c : c+win_cols-1);
        current_var = var(sub_Z(:));
        if current_var > max_var
            max_var = current_var;
            best_r = r; best_c = c;
        end
    end
end

Z_opt = Z_raw(best_r : best_r+win_rows-1, best_c : best_c+win_cols-1);
X_opt = X_full(best_r : best_r+win_rows-1, best_c : best_c+win_cols-1);
Y_opt = Y_full(best_r : best_r+win_rows-1, best_c : best_c+win_cols-1);

%% 4. 坐标归零与高保真降采样 (提升至 10m 分辨率)
X_opt = X_opt - min(X_opt(:));
Y_opt = Y_opt - min(Y_opt(:));
Z_opt = Z_opt - min(Z_opt(:));

% 将 3km x 3km 区域重采样至 300x300，满足测绘级别的地形特征提取
target_grid_size = 300; 
scale_factor = target_grid_size / size(Z_opt, 1);

Z_final = imresize(Z_opt, scale_factor, 'bicubic');
X_final = imresize(X_opt, scale_factor, 'bicubic');
Y_final = imresize(Y_opt, scale_factor, 'bicubic');

disp('区域截取完成，开始计算地形物理特征...');

%% 5. 提取核心地形特征与计算 TW-CVT 密度矩阵 (核心算法输入)
% 5.1 计算坡度 (Slope, 单位: 度)
grid_spacing = X_final(1,2) - X_final(1,1);
[dzdx, dzdy] = gradient(Z_final, grid_spacing, grid_spacing);
Slope_final = atan(sqrt(dzdx.^2 + dzdy.^2)) * 180 / pi;

% 5.2 计算地形粗糙度 (Roughness)
% 使用基于表面积比例的经典定义 (面积比值近似: 1 / cos(坡度角))
Roughness_final = 1 ./ cos(Slope_final * pi / 180);

% 5.3 构建地形密度函数矩阵 (Density Map)
% 对坡度和粗糙度进行归一化处理
norm_slope = (Slope_final - min(Slope_final(:))) / (max(Slope_final(:)) - min(Slope_final(:)) + 1e-6);
norm_rough = (Roughness_final - min(Roughness_final(:))) / (max(Roughness_final(:)) - min(Roughness_final(:)) + 1e-6);

% 加权生成密度分布 (基础密度 0.1 保证平原区不会出现划分奇点)
Density_Map = 0.7 * norm_slope + 0.3 * norm_rough + 0.1;

disp('特征提取与密度矩阵构建完毕！');

%% 6. 多维度数据保存与可视化评估
% 保存所有后续算法所需的矩阵
save('Mountain_Env_3km.mat', 'X_final', 'Y_final', 'Z_final', 'Slope_final', 'Roughness_final', 'Density_Map');
disp('环境矩阵及地形特征已保存至 Mountain_Env_3km.mat');

% 绘制地形高程图与密度热力图以供分析
figure('Name', 'Terrain Features Analysis', 'Position', [100, 100, 1200, 500], 'Color', 'white');

% 子图1：高程模型
subplot(1,2,1);
surf(X_final, Y_final, Z_final, 'EdgeColor', 'none');
shading interp; colormap(gca, demcmap(Z_final)); colorbar;
title('3D Terrain Elevation Model (10 m Resolution)');
xlabel('X (m)'); ylabel('Y (m)'); zlabel('Elevation (m)');
daspect([1 1 1]); view(-35, 45); camlight('headlight'); lighting gouraud; grid on;

% 子图2：TW-CVT 任务密度分布热力图
subplot(1,2,2);
imagesc(X_final(1,:), Y_final(:,1), Density_Map);
axis xy; colormap(gca, 'hot'); colorbar;
title('TW-CVT Task Density Map (\rho)');
xlabel('X (m)'); ylabel('Y (m)');
grid on;