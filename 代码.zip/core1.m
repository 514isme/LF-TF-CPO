% =========================================================================
% 面向无人机集群的高效 TW-CVT 动态泰森多边形协同划分算法
% 核心功能：读取密度矩阵，执行 Lloyd 算法，输出 5 架无人机的自适应负载区域
% =========================================================================

clear; clc; close all;

%% 1. 加载地形特征与密度矩阵
disp('正在加载 Mountain_Env_3km.mat 地形数据...');
load('Mountain_Env_3km.mat', 'X_final', 'Y_final', 'Density_Map');

% 获取网格尺寸信息
[num_rows, num_cols] = size(Density_Map);
X_vec = X_final(1, :); % X轴坐标向量
Y_vec = Y_final(:, 1); % Y轴坐标向量

%% 2. 算法参数初始化
num_uavs = 5;               % 无人机数量
max_iters = 80;             % Lloyd 算法最大迭代次数
tolerance = 1e-3;           % 收敛容差 (像素级别的移动距离)

% 初始化 5 个生成元 (Seed Points) 的位置
% 采用随机分布但在一定范围内打散，避免初始点重合
rng(42); % 固定随机种子以保证结果可复现 (论文对照实验必备)
seeds_x = randi([round(num_cols*0.2), round(num_cols*0.8)], num_uavs, 1);
seeds_y = randi([round(num_rows*0.2), round(num_rows*0.8)], num_uavs, 1);

% 构建全图栅格的坐标点集 (用于向量化距离计算)
[Grid_X, Grid_Y] = meshgrid(1:num_cols, 1:num_rows);
grid_points = [Grid_X(:), Grid_Y(:)];
density_vec = Density_Map(:);

% 预分配空间
partition_map = zeros(num_rows, num_cols);
history_seeds = zeros(num_uavs, 2, max_iters);

%% 3. 执行 Lloyd's Algorithm (地形加权质心迭代)
disp('======================================================');
disp('开始执行 TW-CVT 协同划分算法...');
fprintf('总计划迭代次数: %d\n', max_iters);

% 开启进度条
h = waitbar(0, 'TW-CVT 算法迭代中，请稍候...');

for iter = 1:max_iters
    history_seeds(:, :, iter) = [seeds_x, seeds_y];
    
    % 3.1 划分阶段：计算每个栅格点到 5 个生成元的欧式距离
    % 利用 pdist2 进行高效的向量化距离计算
    distances = pdist2(grid_points, [seeds_x, seeds_y]);
    
    % 找到每个栅格点距离最近的生成元索引 (1~5)
    [~, min_idx] = min(distances, [], 2);
    partition_map(:) = min_idx;
    
    % 3.2 更新阶段：计算每个多边形区域的地形加权质心
    new_seeds_x = zeros(num_uavs, 1);
    new_seeds_y = zeros(num_uavs, 1);
    
    for k = 1:num_uavs
        % 提取属于第 k 架无人机的区域掩码
        mask = (partition_map == k);
        
        % 如果某个区域内没有分配到栅格 (极端情况保护)
        if sum(mask(:)) == 0
            new_seeds_x(k) = seeds_x(k);
            new_seeds_y(k) = seeds_y(k);
            continue;
        end
        
        % 提取该区域的坐标和对应的地形密度
        region_x = Grid_X(mask);
        region_y = Grid_Y(mask);
        region_density = Density_Map(mask);
        
        % 计算加权质心公式： C = sum(x * rho) / sum(rho)
        total_density = sum(region_density);
        new_seeds_x(k) = sum(region_x .* region_density) / total_density;
        new_seeds_y(k) = sum(region_y .* region_density) / total_density;
    end
    
    % 3.3 收敛判定：检查生成元的移动距离是否小于容差
    move_dist = max(sqrt((new_seeds_x - seeds_x).^2 + (new_seeds_y - seeds_y).^2));
    
    % 终端进度显示
    if mod(iter, 5) == 0 || iter == 1
        fprintf('迭代 [%02d/%02d] - 最大阵眼移动距离: %.4f pixels\n', iter, max_iters, move_dist);
    end
    
    % 更新进度条
    waitbar(iter / max_iters, h, sprintf('迭代中: %d / %d (误差: %.2f)', iter, max_iters, move_dist));
    
    seeds_x = new_seeds_x;
    seeds_y = new_seeds_y;
    
    if move_dist < tolerance
        fprintf('算法在第 %d 次迭代达到收敛条件！\n', iter);
        break;
    end
end

close(h);
disp('TW-CVT 协同划分完成！');
disp('======================================================');

%% 4. 结果高保真可视化 (论文直出标准)
figure('Name', 'TW-CVT Multi-UAV Cooperative Partitioning', 'Position', [150, 150, 900, 700], 'Color', 'white');

% 绘制地形密度热力图作为底图
imagesc(X_vec, Y_vec, Density_Map);
axis xy; colormap(gca, 'hot'); 
hold on;

% 叠加 TW-CVT 划分边界
% 提取边界点
[~, contour_obj] = contour(X_vec, Y_vec, partition_map, 0.5:1:num_uavs+0.5, 'LineColor', 'cyan', 'LineWidth', 2.5);

% 绘制无人机生成元 (阵眼) 的最终位置和迭代轨迹
colors = lines(num_uavs);
for k = 1:num_uavs
    % 将栅格索引转换为真实的物理坐标 (米)
    phys_seed_x = interp1(1:num_cols, X_vec, seeds_x(k));
    phys_seed_y = interp1(1:num_rows, Y_vec, seeds_y(k));
    
    % 画阵眼
    plot(phys_seed_x, phys_seed_y, 'p', 'MarkerSize', 18, 'MarkerEdgeColor', 'white', 'MarkerFaceColor', colors(k,:), 'LineWidth', 1.5);
    
    % 画轨迹
    traj_x = interp1(1:num_cols, X_vec, squeeze(history_seeds(k, 1, 1:iter)));
    traj_y = interp1(1:num_rows, Y_vec, squeeze(history_seeds(k, 2, 1:iter)));
    plot(traj_x, traj_y, 'w--', 'LineWidth', 1.2);
    
    % 标注编号
    text(phys_seed_x + 50, phys_seed_y + 50, sprintf('UAV %d', k), 'Color', 'white', 'FontSize', 12, 'FontWeight', 'bold');
end

title('TW-CVT 5-UAV Cooperative Task Partitioning on Density Map', 'FontSize', 14);
xlabel('X Position (m)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Y Position (m)', 'FontSize', 12, 'FontWeight', 'bold');
legend('Density Map', 'Voronoi Boundaries', 'Final Seed Positions', 'Optimization Trajectories', 'Location', 'northeastoutside');
grid on; hold off;

% 提取物理坐标边界，方便下一步微观覆盖算法调用
Partition_Result.map = partition_map;
Partition_Result.seeds_phys = [interp1(1:num_cols, X_vec, seeds_x), interp1(1:num_rows, Y_vec, seeds_y)];
save('Partition_Result.mat', 'Partition_Result');
disp('分区结果已保存至 Partition_Result.mat，准备进入下一步微观路径规划。');