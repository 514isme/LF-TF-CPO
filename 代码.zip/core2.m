% =========================================================================
% 面向无人机集群的三维仿地牛耕法(Boustrophedon)微观航线生成引擎
% 核心功能：在 TW-CVT 划分的不规则多边形内，生成间距 50m 的 3D 仿地测绘航线
% =========================================================================

clear; clc; close all;

%% 1. 加载地形矩阵与分区结果
disp('正在加载环境矩阵与 TW-CVT 分区数据...');
load('Mountain_Env_3km.mat', 'X_final', 'Y_final', 'Z_final');
load('Partition_Result.mat', 'Partition_Result');

partition_map = Partition_Result.map;
[num_rows, num_cols] = size(partition_map);
num_uavs = 5;

% 提取物理坐标系信息
X_vec = X_final(1, :);
Y_vec = Y_final(:, 1);
dx = X_vec(2) - X_vec(1); % 栅格物理分辨率 (10m)
dy = Y_vec(2) - Y_vec(1);

%% 2. 严格工程约束参数设定
footprint_m = 50;         % 无人机测绘作业幅宽 (50米)
flight_altitude = 50;     % 严格仿地飞行相对高度 (50米)

% 将物理幅宽转换为栅格步长
sweep_step = round(footprint_m / dy); 

%% 3. 生成 5 架无人机的 3D 往复航线
disp('======================================================');
disp('开始生成 3D 仿地测绘航线...');

% 预分配一个元胞数组存储 5 架无人机的三维航路点序列
UAV_Paths_3D = cell(num_uavs, 1);

h = waitbar(0, '生成三维仿地航线中...');

for k = 1:num_uavs
    waitbar(k / num_uavs, h, sprintf('正在生成 UAV %d 的路径...', k));
    
    % 提取第 k 架无人机的责任区掩码
    mask = (partition_map == k);
    
    % 寻找该区域在 Y 轴上的有效边界
    valid_y_indices = find(any(mask, 2));
    if isempty(valid_y_indices)
        continue;
    end
    
    min_y = min(valid_y_indices);
    max_y = max(valid_y_indices);
    
    path_x = [];
    path_y = [];
    
    % 采用 Boustrophedon (牛耕法) 逻辑：沿 Y 轴按幅宽步进，在 X 轴上往复扫描
    direction = 1; % 1 表示向右扫，-1 表示向左扫
    
    for r = min_y : sweep_step : max_y
        % 找到当前行属于该区域的 X 边界
        valid_x_in_row = find(mask(r, :));
        
        if isempty(valid_x_in_row)
            continue;
        end
        
        min_x = min(valid_x_in_row);
        max_x = max(valid_x_in_row);
        
        % 根据当前扫描方向生成端点
        if direction == 1
            path_x = [path_x, min_x, max_x];
            path_y = [path_y, r, r];
        else
            path_x = [path_x, max_x, min_x];
            path_y = [path_y, r, r];
        end
        
        % 反转扫描方向
        direction = direction * -1;
    end
    
    % 将栅格坐标转换为真实的 3D 物理坐标
    phys_x = interp1(1:num_cols, X_vec, path_x);
    phys_y = interp1(1:num_rows, Y_vec, path_y);
    
    % 核心约束：三维高程 Z = 当前地形高程 + 相对仿地航高 (50m)
    phys_z = zeros(size(phys_x));
    for i = 1:length(phys_x)
        % 极速优化：直接利用整数行列索引提取地面海拔，避开 interp2 的网格限制
        % 注意：矩阵的索引是 (行, 列)，对应的是 (Y, X)
        row_idx = round(path_y(i));
        col_idx = round(path_x(i));
        ground_z = Z_final(row_idx, col_idx);
        
        phys_z(i) = ground_z + flight_altitude; 
    end
    
    % 保存完整的 3D 轨迹 [X, Y, Z]
    UAV_Paths_3D{k} = [phys_x', phys_y', phys_z'];
    fprintf('UAV %d 航线生成完毕，共包含 %d 个航路点。\n', k, length(phys_x));
end

close(h);
disp('所有航线生成完毕！');
disp('======================================================');

%% 4. 高保真 3D 航线渲染 (面向高质量期刊的视觉呈现)
figure('Name', '3D Terrain-Following Cooperative Trajectories', 'Position', [100, 100, 1000, 800], 'Color', 'white');

% 4.1 绘制带光影的三维高程模型
surf_plot = surf(X_final, Y_final, Z_final, 'EdgeColor', 'none', 'FaceAlpha', 0.85);
shading interp; colormap(demcmap(Z_final)); 
hold on;

% 4.2 叠加 TW-CVT 区域边界 (投影在地形表面上)
[~, contour_obj] = contour3(X_final, Y_final, Z_final + 2, partition_map, 0.5:1:num_uavs+0.5, 'LineColor', 'white', 'LineWidth', 2);

% 4.3 绘制 5 架无人机的悬浮 3D 仿地航线
colors = lines(num_uavs);
for k = 1:num_uavs
    traj = UAV_Paths_3D{k};
    if ~isempty(traj)
        % 绘制带一定宽度的航线，突出质感
        plot3(traj(:,1), traj(:,2), traj(:,3), '-', 'Color', colors(k,:), 'LineWidth', 1.8);
        
        % 在起点标记无人机起飞位置
        plot3(traj(1,1), traj(1,2), traj(1,3), 'p', 'MarkerSize', 15, 'MarkerEdgeColor', 'k', 'MarkerFaceColor', colors(k,:));
        text(traj(1,1), traj(1,2), traj(1,3) + 150, sprintf('UAV %d', k), 'Color', colors(k,:), 'FontSize', 12, 'FontWeight', 'bold');
    end
end

title('3D Terrain-Following Cooperative Photogrammetry Trajectories (5 UAVs)', 'FontSize', 14);
xlabel('X Position (m)', 'FontSize', 11, 'FontWeight', 'bold');
ylabel('Y Position (m)', 'FontSize', 11, 'FontWeight', 'bold');
zlabel('Elevation (m)', 'FontSize', 11, 'FontWeight', 'bold');

daspect([1 1 1]); 
view(-40, 50); 
camlight('headlight'); lighting gouraud; grid on;
legend('3D DEM Terrain', 'TW-CVT Boundaries', 'UAV Flight Paths', 'Location', 'northeast');
hold off;

% 保存包含所有 3D 轨迹的数据结构，供后续能耗积分使用
save('Final_3D_Trajectories.mat', 'UAV_Paths_3D');
disp('最终 3D 轨迹已保存至 Final_3D_Trajectories.mat');